/*
	This file lists external prebuilt libraries that this library depends on
*/

#pragma once

// External Libraries
//===================

#pragma comment( lib, "Foundation.lib" )
#pragma comment( lib, "OpenMaya.lib" )

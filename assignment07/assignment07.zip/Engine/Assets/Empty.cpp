/*
	This file doesn't do anything,
	but exists so that at least one object file is created for the project
*/

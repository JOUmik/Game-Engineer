/*
	This file lists external prebuilt libraries that this library depends on
*/

#pragma once

// Includes
//=========

#include "../Configuration.h"

// External Libraries
//===================

#ifdef EAE6320_ASSERTS_AREENABLED
	#pragma comment( lib, "User32.lib" )
#endif
